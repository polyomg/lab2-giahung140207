package poly.edu.java5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Java5ApplicationTests {

    @Test
    void contextLoads() {
    }

}
